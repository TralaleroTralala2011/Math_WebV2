# QUESTION BANK V254 · KIỂM TOÁN B20

- Bản nền: B19 (đếm trực tiếp 3490 bản ghi câu).
- Bổ sung: **15 dạng ứng viên**, mỗi dạng có 10 câu, tổng **150 câu mới** trên 15 chủ đề.
- Sau B20: **3640/75.000 bản ghi câu hỏi**, còn thiếu **71360** về số lượng.
- Số Word: **150/150**. Số chủ đề có ít nhất một câu: **150/150**.
- Số chủ đề có ít nhất 500 bản ghi: **2/150**.
- Đã xác nhận: cấu trúc 13×10, đếm câu 150 Word, kiểm tra các công thức bằng tính toán độc lập ở phần sinh, không trùng nguyên văn giữa các câu mới trong cùng dạng, CRC ZIP.
- Chưa xác nhận: 7.500 dạng độc lập về bản chất; tính độc lập ngữ nghĩa trên toàn ngân hàng; đúng tuyệt đối tất cả đáp án hiện có; 10 câu thực sự khác nhau theo thẩm định của giáo viên.
- Không được coi 150 câu mới hay các dạng ứng viên là đạt 100% chất lượng.

## Danh sách dạng mới
- 019: Đếm điểm nguyên trong miền ràng buộc tuyến tính (Trung cấp), 10 câu.
- 022: Công thức Heron: diện tích và đại lượng dẫn xuất (Trung cấp), 10 câu.
- 052: Cộng các khoản theo quy luật nhân và suy ngược tổng (Trung cấp), 10 câu.
- 058: Khôi phục dãy bậc hai bằng sai phân hữu hạn (Nâng cao), 10 câu.
- 064: Giới hạn một phía và tính liên tục của hàm từng đoạn (Trung cấp), 10 câu.
- 077: Phân hoạch phép chọn theo số phần tử trong hai nhóm (Nâng cao), 10 câu.
- 108: Gộp số liệu và phương sai chung từ hai nhóm (Trung cấp), 10 câu.
- 117: Khoảng cách đường chéo nhau qua tích hỗn tạp (Nâng cao), 10 câu.
- 122: Thể tích vật thể ghép và vật thể bị khoét bằng phép cộng trừ (Trung cấp), 10 câu.
- 127: Chùm mặt phẳng qua giao tuyến của hai mặt phẳng (Nâng cao), 10 câu.
- 139: Phân biệt lỗ hổng đồ thị và tiệm cận đứng sau khi khử nhân tử (Trung cấp), 10 câu.
- 144: Phân tích vectơ theo thành phần song song và vuông góc (Trung cấp), 10 câu.
- 070: Phân tích tham số và giá trị đặc trưng của mô hình dao động tuần hoàn (Trung cấp), 10 câu.
- 014: Miền xác định của hàm hợp với điều kiện tầng ngoài (Trung cấp), 10 câu.
- 056: Suy số hạng và công sai từ đa thức tổng Sₙ (Trung cấp), 10 câu.

## Nguồn tham khảo phạm vi kiến thức
- OLM, SGV Toán 11, chuyên đề dãy số: https://thlehongphonght.olm.vn/index.php/thu-vien-so/doc-sach/sach.4491474754.4491474754
- VietJack, phương trình mặt phẳng: https://vietjack.com/toan-lop-12/phuong-trinh-mat-phang.jsp
Các câu mới được biên soạn độc lập, không sao chép nguyên văn nguồn.
