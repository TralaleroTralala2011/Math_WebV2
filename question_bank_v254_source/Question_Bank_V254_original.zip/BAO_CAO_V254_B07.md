# QUESTION BANK V254 · B07 · BÁO CÁO TIẾN ĐỘ

**Nguồn:** `Question_Bank_V254.zip` bản B06, gồm 150 tài liệu Word.

**Thực hiện đợt B07:** thêm **30 dạng ứng viên** cho **30 chủ đề trước đây trống**, với **300 câu hỏi** tự soạn, mỗi dạng 10 câu, đáp án và hướng giải.

- Số câu đếm theo nhãn trong Word trước: **2130**.
- Số câu đếm theo nhãn trong Word sau: **2430**.
- Chủ đề có ít nhất một câu: **120/150**.
- Chủ đề chưa có câu: **30/150**.
- Mục tiêu: **7.500 dạng độc lập và 75.000 câu**.
- **Chưa đạt yêu cầu tối thiểu 5.000 dạng mới.** Không nâng số lượng bằng ID giả hoặc biến thể thay số.
- **Dạng đạt đủ kiểm định độc lập ngữ nghĩa và đáp án trong ngân hàng: chưa chứng nhận.**

## Kết quả kiểm thử

- Dữ liệu mới: 300 câu khác nguyên văn, 30 loại phương pháp mô tả riêng.
- Số phép kiểm thử đại diện được mã hóa bằng SymPy/Fraction: 25 / 25 đạt.
- Cảnh báo tương đồng ngôn ngữ >= 0,88: 0 cặp. Đây là dấu hiệu rà soát, không đủ để công nhận hay phủ nhận khác biệt ngữ nghĩa.
- Chưa có xác nhận độc lập toàn diện của giáo viên cho mọi đáp án và mọi dạng.

## Chủ đề mới

- **017**: Tìm diện tích tam giác bằng công thức Heron và suy ra đại lượng liên quan (10 câu)
- **018**: Suy ra số cạnh và số đo góc của đa giác từ tổng góc trong và góc ngoài (10 câu)
- **028**: Phân loại nghiệm hệ phương trình tuyến tính chứa tham số (10 câu)
- **031**: Dùng hai đường chéo vuông góc để tính diện tích hình thoi và hình diều (10 câu)
- **033**: Vận dụng định lý tiếp tuyến–cát tuyến và hai cát tuyến (10 câu)
- **038**: Dùng định thức tọa độ để tính diện tích và kiểm tra thẳng hàng (10 câu)
- **047**: Vận dụng định lý phân giác trong tam giác và định lý đảo (10 câu)
- **048**: Liên hệ góc ở tâm, độ dài cung và diện tích hình quạt (10 câu)
- **049**: Dùng tính chất hai góc đối của tứ giác nội tiếp bù nhau (10 câu)
- **052**: Mô hình biến thiên tuần hoàn thực tế bằng hàm sin và cos (10 câu)
- **054**: Chứng minh đường thẳng vuông góc mặt phẳng bằng hai đường cắt nhau (10 câu)
- **059**: Rút gọn tổng hữu hạn bằng phân tích hiệu hai phân thức liên tiếp (10 câu)
- **061**: Khai thác truy hồi Fibonacci bằng tính trực tiếp và quy nạp (10 câu)
- **066**: Tính góc giữa đường thẳng và mặt phẳng qua hình chiếu vuông góc (10 câu)
- **071**: Tìm ảnh qua hợp thành các phép tịnh tiến, đối xứng và quay (10 câu)
- **073**: Tính xác suất có điều kiện từ bảng chéo và cây xác suất (10 câu)
- **077**: Sử dụng đồng nhất thức Pascal và tính đối xứng của hệ số tổ hợp (10 câu)
- **079**: Xác định ảnh điểm và đường thẳng qua phép đối xứng và phép quay cơ bản (10 câu)
- **084**: Giải phương trình lượng giác cơ bản và quy về dạng cơ bản (10 câu)
- **111**: Tính diện tích xung quanh và toàn phần hình trụ từ hình trải (10 câu)
- **121**: Nhận diện quỹ tích số phức từ môđun khoảng cách (10 câu)
- **126**: Viết và kiểm tra phương trình mặt phẳng tiếp xúc mặt cầu (10 câu)
- **132**: Thiết lập phương trình mặt phẳng Oxyz từ điểm và vectơ pháp tuyến (10 câu)
- **133**: Giải phương trình bậc hai trên tập số phức bằng biệt thức (10 câu)
- **134**: Viết phương trình tham số đường thẳng qua điểm với vectơ chỉ phương (10 câu)
- **136**: Tính thể tích hình chóp từ diện tích đáy và chiều cao vuông góc (10 câu)
- **141**: Tìm giao điểm của đồ thị hàm số bằng giải phương trình hoành độ (10 câu)
- **147**: Tính kì vọng và phương sai biến ngẫu nhiên rời rạc có bảng phân phối (10 câu)
- **149**: Tính quãng đường, độ dời và tích lũy bằng tích phân xác định (10 câu)
- **150**: Vận dụng dấu đạo hàm để tìm cực trị của mô hình thực tế (10 câu)

## Ghi chú nguồn tham khảo

Tham khảo phạm vi kiến thức từ danh mục dạng bài Toán 10–12, không sao chép nguyên văn lời giải hoặc đề bài từ trang web.

- https://vietjack.com/toan-lop-10/index.jsp
- https://vietjack.com/toan-lop-12/phuong-phap-toa-do-trong-khong-gian.jsp
