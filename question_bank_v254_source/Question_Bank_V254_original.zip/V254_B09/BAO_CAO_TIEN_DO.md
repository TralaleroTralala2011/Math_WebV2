# QUESTION BANK V254 · B09 · BÁO CÁO TIẾN ĐỘ VÀ CHẤT LƯỢNG

## Kết quả đếm lại trực tiếp từ 150 file Word

- Chủ đề: **150/150 có nội dung**.
- Trước B09: **2.730** bản ghi câu hỏi.
- Bổ sung B09: **30 dạng ứng viên mới ở 30 chủ đề, 10 câu/dạng = 300 câu mới**, với đáp án và lời giải.
- Lũy kế sau B09: **3.030 / 75.000 câu hỏi** (**4,04% theo số lượng bản ghi**).
- Thiếu so với 75.000: **71.970 câu**.
- Yêu cầu 7.500 dạng độc lập: **CHƯA ĐẠT**. 30 dạng mới chỉ ở mức ứng viên; không có kiểm định độc lập toàn ngân hàng.
- Mục tiêu dài hạn 300.000 dạng và 3.000.000 câu: chưa đạt.

## Các quy tắc biên soạn

1. Không tính thay ID, đổi số hoặc đổi câu chữ thành một dạng độc lập mới.
2. Mỗi dạng mới có 10 đề bài biên soạn tách biệt, lựa chọn tình huống/yêu cầu khác nhau, kèm lời giải; vẫn cần phản biện mức độ khác nhau thực chất.
3. Kiểm tra số lượng, trùng nguyên văn, cấu trúc Word, ZIP CRC; có các kiểm tra toán học có chủ đích, **không chứng nhận đã kiểm định toán học 100% số câu**.
4. Giữ nguyên 120 Word ngoài nhóm cập nhật B09, kể cả các phần chưa đủ chuẩn.

## Kết quả kiểm thử

- File Word: 150; có câu: 150.
- Đề mới trùng nguyên văn trong B09: **0**.
- Nhóm đề có cùng mẫu sau khi loại số trong B09: **0 trường hợp dư** (tín hiệu tự động, không khẳng định trùng hoặc độc lập ngữ nghĩa).
- Dạng độc lập được chứng nhận toàn diện: **0** (chưa triển khai hệ thống thẩm định độc lập).
- Tham khảo phạm vi học phần từ OLM/VietJack, tự soạn đề, không chép nguyên văn tài liệu.

## Các file đi kèm

- `150_CHU_DE_WORD/*.docx`: 150 file Word.
- `V254_B09/NEW_30_FORMS_300_QUESTIONS.json`: 30 dạng và 300 câu có trường đề, lời giải, đáp án.
- `V254_B09/BAO_CAO_SO_LUONG.json`: kiểm toán số câu theo từng chủ đề.
- `V254_B09/BAO_CAO_TIEN_DO.md`: báo cáo này.

**Không tuyên bố hoàn thành 100% khi chưa đạt 7.500 dạng và 75.000 câu đạt chuẩn.**
