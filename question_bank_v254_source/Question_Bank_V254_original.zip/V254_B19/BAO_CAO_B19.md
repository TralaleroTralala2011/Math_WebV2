# QUESTION BANK V254 - B19 | Báo cáo thực tế

- File gốc: Question_Bank_V254.zip.
- Tổng 150 file Word giữ nguyên số lượng.
- Trước B19: 3,400 bản ghi câu hỏi.
- Bổ sung: 9 dạng ứng viên × 10 câu = 90 câu trong 9 chủ đề [26, 32, 40, 59, 60, 69, 83, 130, 142].
- Sau B19: 3,490/75.000 bản ghi câu hỏi.
- Còn thiếu: 71,510 câu theo mốc.
- Toàn vẹn: không thay thế nội dung 141 Word ngoài phạm vi, nội dung cũ trong 9 Word được giữ và nối tiếp phần B19.
- Kiểm tra kỹ thuật: các điều kiện chính xác trong 90 câu được kiểm tra tự động tại thời điểm tạo; không có đề B19 trùng nguyên văn.
- Kiểm tra giới hạn: chưa thẩm định độc lập về ngữ nghĩa trên 150 chủ đề; các dạng mới là ứng viên, chưa chứng nhận.
- Việc đủ 75.000 câu hay 7.500 dạng độc lập chưa hoàn thành.
