# QUESTION BANK V254 · B03 · BÁO CÁO

- ZIP gốc: `Question_Bank_V254.zip`.
- Giữ nguyên **150 Word**; sửa **10 file vốn trống**.
- Bổ sung **10 nhóm dạng ứng viên × 10 câu = 100 câu** có đáp án và lời giải.
- Kiểm tra tính toán bằng Python/SymPy: **100/100 đạt**; 100 chữ ký kiểu bài trong 10 nhóm, không trùng nội bộ mỗi nhóm.
- **Không chứng nhận tính độc lập ngữ nghĩa** của các dạng so với toàn bộ 150 chủ đề; chưa đạt 7.500 dạng độc lập và 75.000 câu đáp ứng trọn bộ tiêu chí.
- Không thay đổi nội dung 140 Word còn lại.

## Danh sách dạng mới

| Chủ đề | Nhóm dạng ứng viên | Số câu |
|---|---|---:|
| 003 | Thiết lập và giải bất phương trình bậc nhất từ điều kiện thực tiễn | 10 |
| 010 | Tìm giao điểm và phân loại vị trí tương đối của hai đường thẳng | 10 |
| 029 | Đếm phương án bằng quy tắc nhân | 10 |
| 080 | Xác định ảnh của điểm qua phép quay trong mặt phẳng | 10 |
| 082 | Tìm ảnh của điểm qua phép đối xứng trục | 10 |
| 113 | Xét giao điểm giữa đường thẳng tham số và mặt phẳng trong Oxyz | 10 |
| 119 | Giải phương trình mũ bằng cách quy về cùng cơ số | 10 |
| 131 | Xác định tâm, bán kính và phương trình mặt cầu | 10 |
| 142 | Tọa độ hình chiếu vuông góc lên trục và mặt phẳng tọa độ Oxyz | 10 |
| 144 | Tính và vận dụng tích vô hướng của vectơ trong Oxyz | 10 |

## Chỉ tiêu đúng

50 dạng × 10 câu = 500 câu/chủ đề; 150 chủ đề = **7.500 dạng và 75.000 câu**, không phải 750.000.

## Căn cứ phạm vi kiến thức

- OLM SGK Toán 10 tập 1: https://olm.vn/thu-vien-so/doc-sach/shs-toan-tap-1.4491362330
- OLM SGK Toán 10 tập 2: https://olm.vn/thu-vien-so/doc-sach/shs-toan-tap-2.4491365365
- VietJack chuyên đề tập hợp: https://vietjack.com/toan-lop-10/tap-hop-va-cac-phep-toan-tren-tap-hop.jsp

Đề bài do hệ thống biên soạn; không sao chép nguyên văn từ nguồn công khai.
