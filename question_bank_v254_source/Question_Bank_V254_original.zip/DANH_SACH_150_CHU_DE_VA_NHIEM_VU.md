# DANH SÁCH 150 FILE WORD CẦN BIÊN SOẠN LẠI

Trạng thái: ĐÃ XÓA NỘI DUNG CŨ. Các Word trống, chưa có dạng bài hay câu hỏi được chứng nhận.

## Công việc bắt buộc của mỗi file

1. Xác định phạm vi kiến thức của chủ đề, phân loại Nền tảng / Trung cấp / Nâng cao.
2. Nghiên cứu và xây dựng 2.000 dạng toán khác nhau thực sự về bản chất, tư duy hoặc phương pháp; không tính thay số, ID hay lời văn thành dạng mới.
3. Mỗi dạng có đặc tả, phương pháp giải, dấu hiệu phân biệt và ít nhất 10 câu hỏi khác nhau.
4. Mỗi câu có cách trả lời phù hợp, đáp án đúng và lời giải từng bước; trắc nghiệm chỉ có một đáp án đúng; chấp nhận đáp án tương đương ở câu tự luận.
5. Kiểm thử điều kiện đề, tính đúng toán học, chống trùng nguyên văn và trùng bản chất; chỉ chứng nhận sau kiểm định.
6. Mục tiêu mỗi file: 2.000 dạng độc lập × 10 câu = 20.000 câu; toàn bộ 150 file: 300.000 dạng và 3.000.000 câu.

## Danh mục theo khối lớp

### Toán 10 (50 file)

001. Bai toan thuc te Toan 10 — `001_Toan_10_Bai_toan_thuc_te_Toan_10.docx`
002. Bai toan tong hop đường thang va đường tron toa o — `002_Toan_10_Bai_toan_tong_hop_uong_thang_va_uong_tron_toa_o.docx`
003. Bat phuong trinh va he bat phuong trinh — `003_Toan_10_Bat_phuong_trinh_va_he_bat_phuong_trinh.docx`
004. Bat đẳng thuc va cuc tri trong tam giac — `004_Toan_10_Bat_ang_thuc_va_cuc_tri_trong_tam_giac.docx`
005. Bat đẳng thuc đại so va cuc tri nang cao — `005_Toan_10_Bat_ang_thuc_ai_so_va_cuc_tri_nang_cao.docx`
006. Chung minh hinh hoc bang vecto — `006_Toan_10_Chung_minh_hinh_hoc_bang_vecto.docx`
007. Chung minh hinh hoc va bai toan tong hop — `007_Toan_10_Chung_minh_hinh_hoc_va_bai_toan_tong_hop.docx`
008. Cac truong hop bang nhau cua tam giac — `008_Toan_10_Cac_truong_hop_bang_nhau_cua_tam_giac.docx`
009. Day cung cung va khoang cach đến tam — `009_Toan_10_Day_cung_cung_va_khoang_cach_en_tam.docx`
010. Giao điểm va vi tri tuong đổi cua hai đường thang — `010_Toan_10_Giao_iem_va_vi_tri_tuong_oi_cua_hai_uong_thang.docx`
011. Goc noi tiep va goc o tam nang cao — `011_Toan_10_Goc_noi_tiep_va_goc_o_tam_nang_cao.docx`
012. Goc tao boi hai đường thang va đường cat — `012_Toan_10_Goc_tao_boi_hai_uong_thang_va_uong_cat.docx`
013. Hoan vi chinh hop to hop — `013_Toan_10_Hoan_vi_chinh_hop_to_hop.docx`
014. Ham so — `014_Toan_10_Ham_so.docx`
015. Ham so bac hai va parabol — `015_Toan_10_Ham_so_bac_hai_va_parabol.docx`
016. Ham so bac nhat — `016_Toan_10_Ham_so_bac_nhat.docx`
017. Hinh hoc co ban goc canh va dien tich — `017_Toan_10_Hinh_hoc_co_ban_goc_canh_va_dien_tich.docx`
018. Hinh hoc phang — `018_Toan_10_Hinh_hoc_phang.docx`
019. He bat phuong trinh — `019_Toan_10_He_bat_phuong_trinh.docx`
020. He phuong trinh — `020_Toan_10_He_phuong_trinh.docx`
021. He phuong trinh đổi xung va hoan vi — `021_Toan_10_He_phuong_trinh_oi_xung_va_hoan_vi.docx`
022. He thuc luong trong tam giac — `022_Toan_10_He_thuc_luong_trong_tam_giac.docx`
023. Menh e — `023_Toan_10_Menh_e.docx`
024. Menh e va tap hop — `024_Toan_10_Menh_e_va_tap_hop.docx`
025. Nhi thuc Newton — `025_Toan_10_Nhi_thuc_Newton.docx`
026. Phuong trinh — `026_Toan_10_Phuong_trinh.docx`
027. Phuong trinh chua can thuc nang cao — `027_Toan_10_Phuong_trinh_chua_can_thuc_nang_cao.docx`
028. Phuong trinh va he phuong trinh — `028_Toan_10_Phuong_trinh_va_he_phuong_trinh.docx`
029. Quy tac đếm — `029_Toan_10_Quy_tac_em.docx`
030. Quy tich điểm trong mat phang — `030_Toan_10_Quy_tich_iem_trong_mat_phang.docx`
031. Tam giac va tu giac co ban — `031_Toan_10_Tam_giac_va_tu_giac_co_ban.docx`
032. Thong ke — `032_Toan_10_Thong_ke.docx`
033. Tiep tuyen va day cung cua đường tron — `033_Toan_10_Tiep_tuyen_va_day_cung_cua_uong_tron.docx`
034. Trung điểm va khoang cach trong toa o phang — `034_Toan_10_Trung_iem_va_khoang_cach_trong_toa_o_phang.docx`
035. Tinh chat hinh binh hanh va hinh thoi — `035_Toan_10_Tinh_chat_hinh_binh_hanh_va_hinh_thoi.docx`
036. Tap hop va cac phep toan — `036_Toan_10_Tap_hop_va_cac_phep_toan.docx`
037. Ti so dien tich tam giac — `037_Toan_10_Ti_so_dien_tich_tam_giac.docx`
038. Toa o trong mat phang — `038_Toan_10_Toa_o_trong_mat_phang.docx`
039. Toa o va đường thang trong mat phang — `039_Toan_10_Toa_o_va_uong_thang_trong_mat_phang.docx`
040. To hop va nguyen ly Dirichlet nang cao — `040_Toan_10_To_hop_va_nguyen_ly_Dirichlet_nang_cao.docx`
041. Vecto — `041_Toan_10_Vecto.docx`
042. Xac suat — `042_Toan_10_Xac_suat.docx`
043. Chia Du — `043_Toan_10_Chia_Du.docx`
044. Chia Het — `044_Toan_10_Chia_Het.docx`
045. Phuong Trinh Bac Hai — `045_Toan_10_Phuong_Trinh_Bac_Hai.docx`
046. đường thang — `046_Toan_10_uong_thang.docx`
047. đường trung tuyen phan giac va đường cao — `047_Toan_10_uong_trung_tuyen_phan_giac_va_uong_cao.docx`
048. đường tron — `048_Toan_10_uong_tron.docx`
049. đường tron va cac goc co ban — `049_Toan_10_uong_tron_va_cac_goc_co_ban.docx`
050. định ly Thales va tam giac ong dang — `050_Toan_10_inh_ly_Thales_va_tam_giac_ong_dang.docx`

### Toán 11 (50 file)

051. Bien co độc lap va xac suat co điều kien — `051_Toan_11_Bien_co_oc_lap_va_xac_suat_co_ieu_kien.docx`
052. Bai toan thuc te Toan 11 — `052_Toan_11_Bai_toan_thuc_te_Toan_11.docx`
053. Bai toan thuc te tong hop Toan 11 — `053_Toan_11_Bai_toan_thuc_te_tong_hop_Toan_11.docx`
054. Chung minh tong hop song song va vuong goc — `054_Toan_11_Chung_minh_tong_hop_song_song_va_vuong_goc.docx`
055. Cong thuc luong giac — `055_Toan_11_Cong_thuc_luong_giac.docx`
056. Cap so cong — `056_Toan_11_Cap_so_cong.docx`
057. Cap so nhan — `057_Toan_11_Cap_so_nhan.docx`
058. Day so — `058_Toan_11_Day_so.docx`
059. Day so — `059_Toan_11_Day_so.docx`
060. Day so truy hoi — `060_Toan_11_Day_so_truy_hoi.docx`
061. Day so truy hoi va bai toan cuc tri — `061_Toan_11_Day_so_truy_hoi_va_bai_toan_cuc_tri.docx`
062. Dung thiet dien cua hinh chop va lang tru — `062_Toan_11_Dung_thiet_dien_cua_hinh_chop_va_lang_tru.docx`
063. Gia tri luong giac — `063_Toan_11_Gia_tri_luong_giac.docx`
064. Gioi han — `064_Toan_11_Gioi_han.docx`
065. Gioi han ham so — `065_Toan_11_Gioi_han_ham_so.docx`
066. Goc giua đường thang va mat phang — `066_Toan_11_Goc_giua_uong_thang_va_mat_phang.docx`
067. Goc va khoang cach trong khong gian — `067_Toan_11_Goc_va_khoang_cach_trong_khong_gian.docx`
068. Hai mat phang song song — `068_Toan_11_Hai_mat_phang_song_song.docx`
069. Ham so lien tuc — `069_Toan_11_Ham_so_lien_tuc.docx`
070. Ham so luong giac — `070_Toan_11_Ham_so_luong_giac.docx`
071. Hop thanh cac phep bien hinh — `071_Toan_11_Hop_thanh_cac_phep_bien_hinh.docx`
072. Khoang cach giua hai đường thang cheo nhau — `072_Toan_11_Khoang_cach_giua_hai_uong_thang_cheo_nhau.docx`
073. Mo hinh xac suat co điều kien — `073_Toan_11_Mo_hinh_xac_suat_co_ieu_kien.docx`
074. Mat ben canh ben va đáy cua lang tru hinh chop — `074_Toan_11_Mat_ben_canh_ben_va_ay_cua_lang_tru_hinh_chop.docx`
075. Nhan biet hinh hoc khong gian — `075_Toan_11_Nhan_biet_hinh_hoc_khong_gian.docx`
076. Nhan biet đường thang va mat phang trong khong gian — `076_Toan_11_Nhan_biet_uong_thang_va_mat_phang_trong_khong_gian.docx`
077. Nhi thuc Newton va he so to hop nang cao — `077_Toan_11_Nhi_thuc_Newton_va_he_so_to_hop_nang_cao.docx`
078. Phep bien hinh co ban — `078_Toan_11_Phep_bien_hinh_co_ban.docx`
079. Phep bien hinh trong mat phang — `079_Toan_11_Phep_bien_hinh_trong_mat_phang.docx`
080. Phep quay va phep vi tu — `080_Toan_11_Phep_quay_va_phep_vi_tu.docx`
081. Phep tinh tien va anh cua hinh — `081_Toan_11_Phep_tinh_tien_va_anh_cua_hinh.docx`
082. Phep đổi xung truc — `082_Toan_11_Phep_oi_xung_truc.docx`
083. Phuong trinh luong giac — `083_Toan_11_Phuong_trinh_luong_giac.docx`
084. Phuong trinh luong giac — `084_Toan_11_Phuong_trinh_luong_giac.docx`
085. Phuong trinh luong giac nang cao — `085_Toan_11_Phuong_trinh_luong_giac_nang_cao.docx`
086. Quan he song song trong khong gian — `086_Toan_11_Quan_he_song_song_trong_khong_gian.docx`
087. Quan he song song va vuong goc trong khong gian — `087_Toan_11_Quan_he_song_song_va_vuong_goc_trong_khong_gian.docx`
088. Quan he vuong goc trong khong gian — `088_Toan_11_Quan_he_vuong_goc_trong_khong_gian.docx`
089. Quy nap toan hoc — `089_Toan_11_Quy_nap_toan_hoc.docx`
090. Quy tac đạo ham — `090_Toan_11_Quy_tac_ao_ham.docx`
091. Thiet dien hinh khong gian — `091_Toan_11_Thiet_dien_hinh_khong_gian.docx`
092. Thiet dien va ti so oan trong hinh khong gian — `092_Toan_11_Thiet_dien_va_ti_so_oan_trong_hinh_khong_gian.docx`
093. Thong ke Toan 11 — `093_Toan_11_Thong_ke_Toan_11.docx`
094. To hop va xac suat nang cao — `094_Toan_11_To_hop_va_xac_suat_nang_cao.docx`
095. Xac suat — `095_Toan_11_Xac_suat.docx`
096. đường thang song song voi mat phang — `096_Toan_11_uong_thang_song_song_voi_mat_phang.docx`
097. đường thang vuong goc voi mat phang — `097_Toan_11_uong_thang_vuong_goc_voi_mat_phang.docx`
098. đạo ham — `098_Toan_11_ao_ham.docx`
099. định ly ba đường vuong goc — `099_Toan_11_inh_ly_ba_uong_vuong_goc.docx`
100. Ung dung đạo ham — `100_Toan_11_Ung_dung_ao_ham.docx`

### Toán 12 (50 file)

101. Bieu dien so phuc — `101_Toan_12_Bieu_dien_so_phuc.docx`
102. Bai toan tham so hinh hoc Oxyz — `102_Toan_12_Bai_toan_tham_so_hinh_hoc_Oxyz.docx`
103. Bai toan thuc te Toan 12 — `103_Toan_12_Bai_toan_thuc_te_Toan_12.docx`
104. Bai toan toi uu hinh hoc khong gian — `104_Toan_12_Bai_toan_toi_uu_hinh_hoc_khong_gian.docx`
105. Bai toan tong hop THPT — `105_Toan_12_Bai_toan_tong_hop_THPT.docx`
106. Bat phuong trinh logarit — `106_Toan_12_Bat_phuong_trinh_logarit.docx`
107. Bat phuong trinh mu — `107_Toan_12_Bat_phuong_trinh_mu.docx`
108. Cac so ac trung o xu the va o phan tan — `108_Toan_12_Cac_so_ac_trung_o_xu_the_va_o_phan_tan.docx`
109. Cuc tri — `109_Toan_12_Cuc_tri.docx`
110. Cuc tri khoang cach trong khong gian toa o — `110_Toan_12_Cuc_tri_khoang_cach_trong_khong_gian_toa_o.docx`
111. Dien tich xung quanh va toan phan hinh khoi — `111_Toan_12_Dien_tich_xung_quanh_va_toan_phan_hinh_khoi.docx`
112. Giao tuyen mat cau va mat phang — `112_Toan_12_Giao_tuyen_mat_cau_va_mat_phang.docx`
113. Giao điểm đường thang va mat phang — `113_Toan_12_Giao_iem_uong_thang_va_mat_phang.docx`
114. Gia tri lon nhat va nho nhat — `114_Toan_12_Gia_tri_lon_nhat_va_nho_nhat.docx`
115. Goc giua hai mat phang — `115_Toan_12_Goc_giua_hai_mat_phang.docx`
116. Goc giua đường thang va mat phang Oxyz — `116_Toan_12_Goc_giua_uong_thang_va_mat_phang_Oxyz.docx`
117. Goc va khoang cach Oxyz — `117_Toan_12_Goc_va_khoang_cach_Oxyz.docx`
118. Ham so logarit — `118_Toan_12_Ham_so_logarit.docx`
119. Ham so mu — `119_Toan_12_Ham_so_mu.docx`
120. Hinh hoc khong gian — `120_Toan_12_Hinh_hoc_khong_gian.docx`
121. Hinh hoc so phuc va quy tich — `121_Toan_12_Hinh_hoc_so_phuc_va_quy_tich.docx`
122. Hinh khoi va the tich co ban — `122_Toan_12_Hinh_khoi_va_the_tich_co_ban.docx`
123. Khoang cach tu điểm đến mat phang — `123_Toan_12_Khoang_cach_tu_iem_en_mat_phang.docx`
124. Khao sat va ve o thi ham so — `124_Toan_12_Khao_sat_va_ve_o_thi_ham_so.docx`
125. Mat cau — `125_Toan_12_Mat_cau.docx`
126. Mat phang tiep xuc voi mat cau — `126_Toan_12_Mat_phang_tiep_xuc_voi_mat_cau.docx`
127. Mat phang trong Oxyz — `127_Toan_12_Mat_phang_trong_Oxyz.docx`
128. Nguyen ham va tich phan — `128_Toan_12_Nguyen_ham_va_tich_phan.docx`
129. Phuong trinh logarit — `129_Toan_12_Phuong_trinh_logarit.docx`
130. Phuong trinh mu — `130_Toan_12_Phuong_trinh_mu.docx`
131. Phuong trinh mat cau va tam ban kinh — `131_Toan_12_Phuong_trinh_mat_cau_va_tam_ban_kinh.docx`
132. Phuong trinh mat phang — `132_Toan_12_Phuong_trinh_mat_phang.docx`
133. Phuong trinh so phuc — `133_Toan_12_Phuong_trinh_so_phuc.docx`
134. Phuong trinh đường thang trong Oxyz — `134_Toan_12_Phuong_trinh_uong_thang_trong_Oxyz.docx`
135. So phuc — `135_Toan_12_So_phuc.docx`
136. The tich hinh hoc khong gian — `136_Toan_12_The_tich_hinh_hoc_khong_gian.docx`
137. The tich khoi tron xoay va mo hinh thuc te — `137_Toan_12_The_tich_khoi_tron_xoay_va_mo_hinh_thuc_te.docx`
138. Tiep tuyen — `138_Toan_12_Tiep_tuyen.docx`
139. Tiem can — `139_Toan_12_Tiem_can.docx`
140. Tinh on điều — `140_Toan_12_Tinh_on_ieu.docx`
141. Tuong giao o thi — `141_Toan_12_Tuong_giao_o_thi.docx`
142. Toa o trong khong gian — `142_Toan_12_Toa_o_trong_khong_gian.docx`
143. Toi uu va cuc tri bang tich phan — `143_Toan_12_Toi_uu_va_cuc_tri_bang_tich_phan.docx`
144. Vecto va o dai trong khong gian Oxyz — `144_Toan_12_Vecto_va_o_dai_trong_khong_gian_Oxyz.docx`
145. Van dung toa o Oxyz — `145_Toan_12_Van_dung_toa_o_Oxyz.docx`
146. Vi tri tuong đổi cua hai đường thang trong Oxyz — `146_Toan_12_Vi_tri_tuong_oi_cua_hai_uong_thang_trong_Oxyz.docx`
147. Xac suat va bien ngau nhien — `147_Toan_12_Xac_suat_va_bien_ngau_nhien.docx`
148. đường thang trong Oxyz — `148_Toan_12_uong_thang_trong_Oxyz.docx`
149. Ung dung tich phan — `149_Toan_12_Ung_dung_tich_phan.docx`
150. Ung dung đạo ham — `150_Toan_12_Ung_dung_ao_ham.docx`

## Lưu ý

Tất cả 150 file Word trong ZIP này đều trống, chưa có câu hỏi. Không được hiểu danh mục này là 300.000 dạng đã hoàn thành.
