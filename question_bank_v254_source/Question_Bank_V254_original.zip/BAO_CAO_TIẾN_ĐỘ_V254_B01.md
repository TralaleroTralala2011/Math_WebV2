# QUESTION BANK V254 · BÁO CÁO BỔ SUNG B01

Ngày thực hiện: 11/11/2026. Phạm vi: 149 chủ đề còn lại sau chủ đề 001.

## Các số liệu có thể xác nhận bằng nội dung ZIP

| Hạng mục | Số lượng |
|---|---:|
| Word giữ nguyên trong ZIP | 150 |
| Chủ đề 001 bảo toàn nguyên trạng | 1 |
| Chủ đề khác đã được bổ sung bản thảo | 29 |
| Chủ đề khác chưa biên soạn | 120 |
| Nhóm dạng ứng viên mới | 29 |
| Câu hỏi ứng viên mới (10/nhóm) | 290 |
| Kiểm thử nội bộ của bộ sinh | Có, nhưng chưa hoàn chỉnh |
| Nhóm đạt chứng nhận độc lập toán học toàn ngân hàng | 0 |
| Nhóm được chứng nhận 10 đề khác nhau về bản chất | 0 |

## Điều cần đặc biệt chú ý

Đây là dữ liệu BẢN THẢO: nhiều nhóm câu hỏi vẫn chung một khuôn cấu trúc, chỉ thay dữ kiện hoặc thêm bối cảnh. Vì thế, 290 câu và 29 nhóm chỉ được ghi là **ứng viên**, không tính là đã đạt yêu cầu của người dùng về đa dạng hóa đề bài một cách thực chất. Các phép kiểm thử đều là kiểm tra tự động theo mô hình, không thay cho kiểm duyệt độc lập.

Mục tiêu mở rộng đủ 149 × 50 × 10 = 74.500 câu chưa đạt. Cần biên tập đa dạng câu hỏi, kiểm tra trùng bản chất, sửa các nhóm có mô hình chưa đúng rồi xác nhận từng nhóm.

## Danh sách 29 file Word vừa bổ sung

| ID | Chủ đề | Dạng ứng viên | Câu bản thảo |
|---|---|---:|---:|
| 023 | Toán 10: Mệnh đề | 1 | 10 |
| 025 | Toán 10: Nhị thức Newton | 1 | 10 |
| 027 | Toán 10: Phương trình chứa căn thức nâng cao | 1 | 10 |
| 036 | Toán 10: Tập hợp và các phép toán | 1 | 10 |
| 040 | Toán 10: Tổ hợp và nguyên lý Dirichlet nâng cao | 1 | 10 |
| 043 | Toán 10: Chia dư | 1 | 10 |
| 044 | Toán 10: Chia hết | 1 | 10 |
| 045 | Toán 10: Phương trình bậc hai | 1 | 10 |
| 050 | Toán 10: Định lý Thales và tam giác đồng dạng | 1 | 10 |
| 055 | Toán 11: Công thức lượng giác | 1 | 10 |
| 056 | Toán 11: Cấp số cộng | 1 | 10 |
| 057 | Toán 11: Cấp số nhân | 1 | 10 |
| 060 | Toán 11: Dãy số truy hồi | 1 | 10 |
| 064 | Toán 11: Giới hạn | 1 | 10 |
| 069 | Toán 11: Hàm số liên tục | 1 | 10 |
| 070 | Toán 11: Hàm số lượng giác | 1 | 10 |
| 083 | Toán 11: Phương trình lượng giác | 1 | 10 |
| 089 | Toán 11: Quy nạp toán học | 1 | 10 |
| 090 | Toán 11: Quy tắc đạo hàm | 1 | 10 |
| 101 | Toán 12: Biểu diễn số phức | 1 | 10 |
| 106 | Toán 12: Bất phương trình logarit | 1 | 10 |
| 107 | Toán 12: Bất phương trình mũ | 1 | 10 |
| 109 | Toán 12: Cực trị | 1 | 10 |
| 112 | Toán 12: Giao tuyến mặt cầu và mặt phẳng | 1 | 10 |
| 114 | Toán 12: Giá trị lớn nhất và nhỏ nhất | 1 | 10 |
| 128 | Toán 12: Nguyên hàm và tích phân | 1 | 10 |
| 129 | Toán 12: Phương trình logarit | 1 | 10 |
| 130 | Toán 12: Phương trình mũ | 1 | 10 |
| 139 | Toán 12: Tiệm cận | 1 | 10 |

## Nguồn đối chiếu chương trình

- [OLM Toán 10](https://olm.vn/bg/toan-10-ket-noi-tri-thuc-voi-cuoc-song-19429): tham khảo cấu trúc chủ đề.
- [Thư viện SGV Toán 10 trên OLM](https://sgk.olm.vn/thu-vien-so/doc-sach/sgv-toan.4491359795): đối chiếu phạm vi bài học.
- Các câu hỏi viết mới; không sao chép nguyên văn các nguồn trên.