B08: 30 chu de truoc day trong, 30 dang ung vien, 300 cau hoi; kiem chung co gioi han.
