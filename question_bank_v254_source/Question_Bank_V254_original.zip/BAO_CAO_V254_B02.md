# Báo cáo Question Bank V254 B02

## Kết quả mới

- 27 nhóm dạng ứng viên được biên soạn cho 27 chủ đề trước đây trống.
- 270 câu hỏi mới có đáp án và lời giải.
- 0 nhóm dạng được chứng nhận độc lập toàn hệ thống.
- Chủ đề 001 giữ nguyên 50 dạng ứng viên / 500 câu.
- 29 nhóm B01 / 290 câu vẫn là bản thảo chưa đạt tiêu chuẩn khác biệt thực chất.
- Toàn bộ gói có đủ 150 file Word, 1 file cho mỗi chủ đề.

## Phương thức kiểm tra

Nhiều bài đã có phép đối chiếu số học chính xác hoặc SymPy. Một số đáp án được biên soạn và rà công thức nhưng chưa có kiểm thử tự động độc lập theo từng đề. Kiểm thử hiện tại không thay thế phản biện chuyên môn từng bài hoặc rà trùng ngữ nghĩa trên toàn bộ ngân hàng.

## Phạm vi nguồn tham khảo

- https://www.vietjack.com/toan-lop-10/
- https://www.vietjack.com/giao-an-toan-10/index.jsp

Các bài tập mới được tự biên soạn.

## Các chủ đề bổ sung

- 014: Miền xác định của hàm số có căn và phân thức.
- 015: Dựng hàm số bậc hai từ nhiều kiểu dữ kiện.
- 016: Lập mô hình tuyến tính từ hai phép đo.
- 032: Trung bình số liệu khi thêm, bớt, gộp và thay quan sát.
- 042: Xác suất cổ điển từ đếm không gian mẫu và biến cố.
- 065: Giới hạn hữu hạn của biểu thức dạng 0/0.
- 098: Đạo hàm tại một điểm và ý nghĩa tốc độ tức thời.
- 095: Tổ hợp trong xác suất lấy mẫu không hoàn lại với nhiều kiểu biến cố.
- 125: Phương trình mặt cầu từ tâm và dữ kiện bán kính.
- 127: Lập phương trình mặt phẳng từ điểm và vectơ pháp tuyến.
- 135: Phép toán và tính chất số phức.
- 148: Phương trình tham số đường thẳng Oxyz.
- 022: Giải tình huống đo khoảng cách bằng định lý cosin.
- 034: Trung điểm đoạn thẳng: tính trực tiếp và tìm đầu mút ngược.
- 118: Áp dụng tính chất và định nghĩa logarit.
- 122: Tính thể tích các hình khối từ dữ kiện hình học.
- 103: Mô hình tăng trưởng và suy giảm theo tỉ lệ cố định.
- 093: Trung bình gộp nhóm, trọng số và số liệu thực nghiệm.
- 041: Biến đổi vectơ qua quy tắc tọa độ.
- 013: Quy tắc đếm, hoán vị, chỉnh hợp và tổ hợp trong bài toán thực tế.
- 039: Lập phương trình tổng quát đường thẳng Oxy.
- 051: Xác suất có điều kiện trên các mẫu hữu hạn.
- 063: Giá trị lượng giác qua góc tham chiếu và đối xứng.
- 078: Tìm ảnh của điểm qua phép biến hình tọa độ.
- 108: Các đặc trưng thống kê từ dữ liệu không ghép nhóm.
- 123: Khoảng cách từ điểm đến mặt phẳng trong Oxyz.
- 138: Phương trình tiếp tuyến đồ thị tại hoành độ cho trước.
