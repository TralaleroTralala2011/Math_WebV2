# QUESTION BANK V254 B10 · BÁO CÁO CẬP NHẬT

- **File chính cần tải:** `Question_Bank_V254.zip` (tệp ZIP đầy đủ, bao gồm 150 Word).
- **Trước B10:** 3,030 bản ghi câu hỏi.
- **B10 bổ sung:** 6 dạng ứng viên, 10 câu/dạng, tổng **60 câu mới**, tại chủ đề 015, 016, 039, 042, 118, 123.
- **Sau B10:** 3,090 / 75.000 bản ghi câu hỏi; còn thiếu 71,910.
- **Tổng Word:** 150. Giữ nguyên byte của 144 Word không chỉnh trong B10.
- **Dạng độc lập có chứng nhận đầy đủ:** chưa có cơ sở công nhận; 6 dạng B10 là ứng viên.

## Kiểm định B10
- Kiểm tra tính toán có cấu trúc cho 60 câu: các hệ số, xác suất, tọa độ và tập xác định được tính theo công thức và kiểm tra giá trị ở bước sinh đề.
- Trùng đề nguyên văn trong 60 câu mới: 0. Trùng sau thay hằng số bằng nhãn: 0 (tín hiệu hình thức, không chứng minh đa dạng về tư duy).
- Chưa xác minh độc lập về mặt ngữ nghĩa với toàn bộ 150 chủ đề; chưa có hội đồng giáo viên đánh giá tất cả.
- Không sao chép nguyên văn câu hỏi từ nguồn Internet. Các nguồn chỉ dùng đối chiếu phạm vi kiến thức.
- Chưa đạt 7.500 dạng và 75.000 câu; không báo hoàn thành 100%.
