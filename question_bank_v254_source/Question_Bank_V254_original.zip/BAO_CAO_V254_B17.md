# QUESTION BANK V254 — B17

- Tên ZIP chính: `Question_Bank_V254.zip`.
- Đợt này: +2 dạng ứng viên, +20 câu hỏi trong chủ đề 046 và 101.
- Tổng bản ghi dự kiến: 3.270/75.000, cần xác minh trực tiếp từ Word.
- Dạng 046: đối xứng điểm qua đường thẳng bằng hình chiếu, 10 đề khác nhau về yêu cầu.
- Dạng 101: quỹ tích số phức theo môđun, 10 đề khác nhau về quỹ tích hoặc điều kiện phụ.
- Kiểm tra: các phép tính trọng yếu, 10 đề khác nguyên văn mỗi dạng, ZIP CRC và render.
- **Chưa được chứng nhận độc lập ngữ nghĩa, tính toán toàn bộ dữ liệu cũ, hay 100% mục tiêu.**
