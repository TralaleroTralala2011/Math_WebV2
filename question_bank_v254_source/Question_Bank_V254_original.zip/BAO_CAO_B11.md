# QUESTION BANK V254 · Báo cáo B11

## Bản chính
`Question_Bank_V254.zip` là bản tích lũy chính, gồm 150 file Word, lưu tất cả cập nhật B01–B11.

## Đếm trực tiếp từ các file Word
- Trước B11: **3.090** nhãn câu hỏi, 150 chủ đề có câu hỏi.
- Sau B11: **3.110** nhãn câu hỏi, 150 chủ đề có câu hỏi.
- Mới trong B11: **2 dạng ứng viên, 20 câu** cho chủ đề `024_Toan_10_Menh_e_va_tap_hop.docx`.
- Chỉ tiêu: **7.500 dạng độc lập và 75.000 câu**, tức 50 dạng và 500 câu mỗi chủ đề.
- Câu chưa đạt mốc số lượng: **71.890**.
- Tỉ lệ số bản ghi câu hỏi: **4,1467%**.

## Hai dạng mới
1. Phủ định lượng từ và kiểm tra đúng sai bằng chứng minh hoặc phản ví dụ (10 câu).
2. Phân biệt điều kiện cần, đủ và tương đương qua chứng minh và phản ví dụ (10 câu).

## Phạm vi kiểm tra
- Đủ 150 DOCX, ZIP không lỗi CRC.
- So sánh số nhãn câu hỏi cũ và mới: đúng +20.
- 20 câu mới có đề, đáp án, lập luận giải thích; không trùng nguyên văn trong 20 đề mới.
- Đã kết xuất và kiểm tra trực quan tài liệu chủ đề 024.
- **Chưa chứng nhận độc lập ngữ nghĩa giữa toàn bộ dạng, chưa kiểm tra độc lập bởi giáo viên và chưa đạt 100% chỉ tiêu.**

## Tham khảo phạm vi kiến thức
- https://vietjack.com/toan-lop-10/menh-de-tap-hop.jsp
- https://dgnl.olm.vn/index.php/bg/toan-10
Không sao chép nguyên văn câu hỏi từ các nguồn này.
