# BÁO CÁO V254 B22 – BẢN DỰ THI / TIẾN ĐỘ THỰC TẾ

Nguồn: `Question_Bank_V254.zip` phiên B21. Bản cập nhật: B22.

- Toàn bộ chủ đề: 150 Word, bảo toàn mọi Word gốc ngoài 18 Word được nối thêm.
- Bổ sung B22: 18 dạng ứng viên với 180 câu hỏi có đáp án/lời giải.
- Số câu đếm trực tiếp bằng nhãn `Câu` từ Word sau cập nhật: 4040/75.000.
- Còn thiếu theo chỉ tiêu bản ghi: 70960.
- Chủ đề đạt 500 bản ghi: 2/150.
- KIỂM TRA: mỗi dạng B22 có đúng 10 câu; đề mới không trùng nguyên văn; DOCX mở được; ZIP CRC hợp lệ; 132 DOCX ngoài phạm vi giữ nguyên byte.
- **KHÔNG** chứng nhận 100% tính độc lập ngữ nghĩa và độ đúng toàn ngân hàng. Nhóm B22 được ghi là **ứng viên**, cần hội đồng/chuyên gia duyệt trước khi công bố đạt chuẩn.
- Số dạng độc lập đã cấp chứng nhận toàn diện: chưa được thiết lập; không được suy từ tổng ID.

## Các dạng B22
- 034 | B22-034-01 | Tọa độ điểm chia đoạn theo tỉ lệ trong | 10 câu | Trung cấp
- 047 | B22-047-01 | Trọng tâm tam giác bằng tính chất trung tuyến | 10 câu | Trung cấp
- 048 | B22-048-01 | Độ dài dây cung từ bán kính và khoảng cách tâm | 10 câu | Trung cấp
- 063 | B22-063-01 | Khôi phục sin và cos theo góc phần tư | 10 câu | Nền tảng
- 065 | B22-065-01 | Giới hạn hữu tỉ khi x tiến tới vô cực | 10 câu | Trung cấp
- 098 | B22-098-01 | Tính đạo hàm tại một điểm bằng giới hạn thương sai phân | 10 câu | Nền tảng
- 100 | B22-100-01 | Viết tiếp tuyến bằng đạo hàm tại tiếp điểm | 10 câu | Trung cấp
- 134 | B22-134-01 | Đường thẳng vuông góc mặt phẳng qua một điểm | 10 câu | Trung cấp
- 145 | B22-145-01 | Thể tích hình hộp bằng tích hỗn tạp ba vectơ | 10 câu | Trung cấp
- 150 | B22-150-01 | Vận tốc và gia tốc tức thời từ hàm tọa độ vị trí | 10 câu | Trung cấp
- 136 | B22-136-01 | Thể tích lăng trụ theo diện tích đáy và chiều cao vuông góc | 10 câu | Nền tảng
- 049 | B22-049-01 | Tích đoạn thẳng hai dây cung giao nhau | 10 câu | Trung cấp
- 111 | B22-111-01 | Diện tích mặt bên hình nón từ hình trải | 10 câu | Trung cấp
- 017 | B22-017-01 | Diện tích tam giác theo hai cạnh và góc xen giữa | 10 câu | Nền tảng
- 025 | B22-025-01 | Hệ số một số hạng của khai triển nhị thức Newton | 10 câu | Trung cấp
- 030 | B22-030-02 | Đường tròn Apollonius với tỉ số khoảng cách 2:1 | 10 câu | Trung cấp
- 106 | B22-106-01 | Bất phương trình logarit cơ số thuộc (0;1) | 10 câu | Trung cấp
- 140 | B22-140-02 | Tham số để hàm bậc ba đồng biến trên toàn R | 10 câu | Nâng cao

## Nguồn đối chiếu phạm vi chương trình
- OLM SGK Toán 10 tập 2: https://olm.vn/thu-vien-so/doc-sach/shs-toan-tap-2.4491365365
- VietJack các dạng Toán 11: https://www.vietjack.com/toan-lop-11/
- VietJack chuyên đề phương trình lượng giác Toán 11: https://vietjack.com/toan-lop-11/phuong-trinh-luong-giac.jsp

Các đề B22 được biên soạn riêng theo công thức, không sao chép nguyên văn nguồn tham khảo.
