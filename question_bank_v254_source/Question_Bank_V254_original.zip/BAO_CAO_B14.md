# Báo cáo Question Bank V254 · B14 (12/11/2026)

**Tệp chính:** `Question_Bank_V254.zip` (150 Word nguyên vẹn).

- Trước B14: 3.160 nhãn câu hỏi trong 150 Word.
- B14 mới: 3 dạng ứng viên tại chủ đề 013, 014, 015, tổng 30 đề kèm đáp án và lời giải.
- Sau B14: **3.190/75.000 nhãn câu hỏi**, đếm trực tiếp từ các đoạn mở đầu bằng `Câu <số>` trong toàn bộ 150 Word; thiếu 71.810 nhãn câu hỏi so với chỉ tiêu số lượng.
- Các chủ đề 013, 014, 015 hiện mỗi chủ đề có 30 câu (trước đó 20).
- Bộ dữ liệu JSON cho 3 nhóm mới lưu tại thư mục `B14_DU_LIEU/` trong ZIP.
- Đã đối chiếu toán học bằng biểu thức, công thức tổ hợp và phép thử độc lập cho các trường hợp có thể tự động kiểm tra; Word 013, 014, 015 đã kết xuất để xem trang.
- **Chưa có chứng nhận độc lập toàn diện** cho ba dạng mới hoặc cho toàn bộ ngân hàng. Kiểm tra trùng nguyên văn không thay thế kiểm tra trùng bản chất; các số liệu đã nêu là bản ghi, không phải số đã được chứng nhận.
- Nguồn tham khảo danh mục kiến thức: https://vietjack.com/toan-lop-10/ham-so-bac-nhat-va-bac-hai.jsp và https://vietjack.com/toan-lop-10/ . Câu hỏi B14 được soạn mới, không sao chép nguyên văn.
- Mục tiêu dài hạn 7.500 dạng × 10 câu chưa hoàn thành.
