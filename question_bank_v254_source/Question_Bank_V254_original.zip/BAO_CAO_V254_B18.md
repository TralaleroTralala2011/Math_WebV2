# QUESTION BANK V254 · B18 | Báo cáo kiểm toán

- Ngày cập nhật: 12/11/2026.
- File ngân hàng chính: `Question_Bank_V254.zip`.
- Word trong ZIP: **150/150**.
- Số bản ghi câu hỏi trước B18 (đếm trực tiếp từ Word): **3,270**.
- Bổ sung: **13 dạng ứng viên mới**, mỗi dạng **10 câu**, tổng **130 câu**.
- Số bản ghi câu hỏi sau B18: **3,400/75.000**.
- Còn thiếu theo số lượng: **71,600 câu**.
- Phân bố yêu cầu: 50 dạng × 10 câu = 500 câu/chủ đề, 150 chủ đề tổng 7.500 dạng và 75.000 câu.
- **Không** công nhận 7.500 dạng hoàn thành; **không** có cơ sở xác nhận tính độc lập toàn diện từ tất cả dữ liệu trước đây.
- **Không** chứng nhận 100% chất lượng hoặc tính độc lập ngữ nghĩa của 13 dạng mới.

## Chủ đề vừa cập nhật

| Chủ đề | Dạng ứng viên mới | Câu mới |
|---|---:|---:|
| 014 · Kiểm tra tính chẵn, lẻ từ miền xác định và phép thế đối xứng | 1 | 10 |
| 032 · Phương sai của dữ liệu thô, bảng tần số và phép biến đổi | 1 | 10 |
| 041 · Chia đoạn thẳng theo tỉ số bằng phương trình vectơ | 1 | 10 |
| 045 · Hệ thức Viète và Viète đảo trong suy luận về nghiệm | 1 | 10 |
| 051 · Kiểm tra tính độc lập và xác suất giao của hai biến cố | 1 | 10 |
| 064 · Khử dạng vô định bằng nhân biểu thức liên hợp | 1 | 10 |
| 090 · Quy tắc đạo hàm thương và hệ số góc tiếp tuyến | 1 | 10 |
| 114 · Tối ưu hàm bậc ba trên đoạn bằng bảng điểm tới hạn | 1 | 10 |
| 121 · Quỹ tích đường trung trực qua điều kiện cách đều hai số phức | 1 | 10 |
| 127 · Mặt phẳng qua ba điểm không thẳng hàng trong Oxyz | 1 | 10 |
| 128 · Tính tích phân nhờ tính chẵn lẻ trên đoạn đối xứng | 1 | 10 |
| 147 · Phân phối siêu bội khi lấy mẫu không hoàn lại | 1 | 10 |
| 149 · Giá trị trung bình của hàm trên một khoảng bằng tích phân | 1 | 10 |

## Kiểm tra đã thực hiện

1. 150 Word đọc được bằng python-docx; 13 Word được sửa có đúng 10 câu mới mỗi file.
2. Đề bài của 10 câu trong cùng một dạng không trùng nguyên văn.
3. Các dữ kiện có áp dụng phép tính chính xác, SymPy hoặc tổ hợp theo mẫu đã biên soạn; một số bước trong lời giải vẫn cần giáo viên kiểm tra độc lập.
4. ZIP đã được kiểm tra CRC và không xóa mất các Word cũ.
5. Các loại yêu cầu được đa dạng hóa như chứng minh tính chất, suy ngược dữ kiện, tìm tham số, kiểm tra trường hợp và tính đại lượng khác nhau. Chưa thay thế bước đánh giá ngữ nghĩa thủ công trên mọi câu.

## Trạng thái cần phân biệt

- **Có bản ghi**: tìm thấy đầu mục `Câu N` trong Word; chỉ là chỉ tiêu số lượng.
- **Ứng viên**: có đề, đáp án và lời giải, đang chờ kiểm chứng độc lập hoàn toàn.
- **Đạt chuẩn**: cần rà chính xác toán học, không trùng dạng cũ, 10 câu khác nhau thực chất; chưa có giấy chứng nhận cho toàn ngân hàng.

Dữ liệu cũ vẫn giữ nguyên, không lấy V253 nhập đè lên V254.

## Kiểm tra bổ sung sau khi xuất Word

- **80/80 phép đối chiếu tính toán độc lập đã chạy đạt**, gồm giới hạn, cực trị, tích phân, xác suất chọn mẫu, tọa độ và đạo hàm. Chi tiết trong `V254_B18_KIEM_TRA_TOAN_HOC.txt`.
- **13/13 tài liệu Word mới đã kết xuất thành trang ảnh thành công**, đã kiểm tra ảnh các trang mới để phát hiện lỗi bố cục.
- Kiểm tra 80 phép tính **không tương đương** chứng nhận đúng toàn bộ 130 câu, và **không chứng minh** tính khác biệt ngữ nghĩa trong mỗi dạng.
