# Question Bank V254 B15

Tăng 2 dạng ứng viên, 20 câu hỏi tại chủ đề 043 và 044. Các chủ đề còn lại giữ nguyên. Đã kiểm tra đồng dư, thuật toán Euclid, nhưng chưa có chứng nhận độc lập toàn ngân hàng.
