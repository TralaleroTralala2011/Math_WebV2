#!/usr/bin/env python3
"""Đếm câu thật từ 150 Word và kiểm tra tính toàn vẹn ZIP.
Không tự chứng nhận dạng độc lập hoặc độ đúng toán học.
"""
import zipfile,io,re,csv,sys
from docx import Document
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else 'Question_Bank_V254.zip')
with zipfile.ZipFile(p) as z:
  assert z.testzip() is None,'ZIP CRC không đạt'
  docs=sorted(n for n in z.namelist() if re.search(r'/\d{3}_.*\.docx$',n))
  assert len(docs)==150,f'Cần đúng 150 Word, hiện {len(docs)}'
  rows=[]
  for name in docs:
    doc=Document(io.BytesIO(z.read(name)))
    labels=[p.text for p in doc.paragraphs if re.match(r'^Câu(?:\s+B22\.)?\s*\d+',p.text,re.I)]
    rows.append({'chu_de':name.split('/')[-1],'so_cau':len(labels),'thieu_so_voi_500':max(0,500-len(labels))})
  print('Tài liệu Word:',len(docs))
  print('Tổng bản ghi câu:',sum(r['so_cau'] for r in rows))
  print('Chủ đề đạt 500 câu về số lượng:',sum(r['so_cau']>=500 for r in rows))
  print('Chủ đề còn thiếu:',sum(r['so_cau']<500 for r in rows))
  print('CHƯA kiểm chứng độ độc lập ngữ nghĩa, không tự công nhận đạt chuẩn.')
