# QUESTION BANK V254 B50 · BÁO CÁO KIỂM TOÁN

## Đã thực hiện

- Nguồn: B49 (150 Word, 75.064 nhãn câu).
- B50: thêm **10.000 câu luyện tập ứng viên** phân bổ khắp **150 chủ đề**, cộng **10 bài toán lập hệ hai ẩn với 10 bối cảnh riêng** ở chủ đề 020.
- Tổng nhãn câu: **85.074**, đếm từ **150/150 Word**; tối thiểu **566 nhãn/chủ đề**.
- Câu B50 trùng nguyên văn với kho B46–B49 sau bộ lọc: **0**; B50 trùng nội bộ: **0**. Không tương đương kiểm tra trùng ngữ nghĩa.
- Hình thức câu: {'MCQ': 7116, 'Free': 1994, 'TF': 900}. Trắc nghiệm có đúng 1 phương án có giá trị bằng đáp án theo phép kiểm bằng phân số: **7116/7116**.
- Kiểm tra ZIP: không lỗi CRC; 150 Word; số nhãn mỗi Word được kiểm đếm lại; SHA256 bản chính và bản xuất trùng nhau.

## Giới hạn chất lượng

- **Chưa chứng nhận 7.500 dạng độc lập**; đổi hệ số hoặc dữ kiện không được tính là dạng mới. Nhiều câu B50 là biến thể tham số của cùng một kỹ năng, chỉ được tính ở mốc bản ghi ứng viên.
- **Chưa chứng nhận 85.074 câu đạt chuẩn**: kiểm tra duy nhất đáp án trắc nghiệm không thay thế kiểm định sư phạm/toán học độc lập hoặc phát hiện mọi lỗi mô hình.
- 10 bài hệ phương trình được soạn theo 10 bối cảnh khác nhau, thuộc cùng một dạng ứng dụng lập hệ, không phải 10 dạng khác nhau.
- Chưa cập nhật cơ sở dữ liệu SQLite/FastAPI; đây là tập tài liệu Word + bản ghi JSONL.

## Tham khảo cấu trúc kiến thức

- https://olm.vn/thu-vien-so/doc-sach/shs-toan-tap-1.4491362330
- https://www.vietjack.com/toan-lop-11/cac-dang-toan-ve-cap-so-cong-va-cach-giai-dbmoi-2021.jsp

Các câu mới được biên soạn bằng mô hình toán học, không sao chép nguyên văn đề trên website.

## Kiểm tra bổ sung

- 10 bài toán lập hệ khác bối cảnh trong chủ đề 020 đã được giải lại độc lập bằng SymPy: 10/10 cho đúng cặp nghiệm đã biên soạn.
- Hai tài liệu Word mẫu (chủ đề 020 và 056) đã kết xuất thành lần lượt 70 và 57 trang PNG; quan sát các trang cuối không thấy cắt chữ hoặc tràn lề. Không xem đây là kiểm thử trực quan của cả 150 Word.
