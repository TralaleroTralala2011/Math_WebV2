# QUESTION BANK V254 B51 · BÁO CÁO KIỂM TOÁN

- Gốc: **B50**, 150 Word và **85.074 nhãn câu**.
- B51: **+10.000 câu luyện tập công thức ứng viên** trên 150 chủ đề; **+50 câu biên soạn theo 5 phương pháp**, mỗi phương pháp 10 câu có bối cảnh/yêu cầu khác nhau và phép toán được kiểm lại.
- Tổng: **95.124 nhãn câu**, tối thiểu **632 nhãn/chủ đề**.
- Tổng câu B51: **10.050**, không trùng nguyên văn với các câu ghi nhận trong JSONL B46–B50; không trùng nội bộ B51. KHÔNG thay thế chống trùng ngữ nghĩa toàn bộ ngân hàng.
- Trắc nghiệm có một đáp án đúng theo phép so sánh phân số: **7122/7122**. Hình thức B51: {'MCQ': 7122, 'Free': 2028, 'TF': 900}.
- Năm nhóm phương pháp biên soạn: 043 Hệ hai đồng dư/CRT; 032 Khoảng tứ phân vị; 042 Bayes; 045 dấu biệt thức theo tham số; 132 mặt phẳng qua 3 điểm bằng tích có hướng.
- Có bảng kiểm toán 150 chủ đề với số **nhãn phương pháp ứng viên**, không gọi đó là số dạng toán độc lập.

## Giới hạn cần công bố rõ

- Đã vượt mốc **75.000 nhãn câu**, nhưng KHÔNG chứng nhận đủ **7.500 dạng thực sự khác bản chất** hoặc 75.000 câu đạt trọn bộ tiêu chí.
- 10.000 câu công thức có thể khác nhau chủ yếu ở tham số, KHÔNG được công nhận thành dạng mới.
- 50 câu biên soạn đã kiểm tra tính toán ở 5 nhóm nhưng chưa duyệt độc lập toàn bộ về tính sư phạm, nguồn gốc và trùng ngữ nghĩa trong tất cả Word.
- Không nhập trực tiếp vào SQLite/FastAPI của website MATH_WEB, chỉ cập nhật ZIP Word + JSONL.

## Nguồn đối chiếu cấu trúc kiến thức (không sao chép đề)

- VietJack danh mục các dạng Toán 11: https://www.vietjack.com/toan-lop-11/index.jsp
- VietJack cấp số cộng và cấp số nhân: https://www.vietjack.com/toan-lop-11/day-so-cap-so-cong-va-cap-so-nhan.jsp
