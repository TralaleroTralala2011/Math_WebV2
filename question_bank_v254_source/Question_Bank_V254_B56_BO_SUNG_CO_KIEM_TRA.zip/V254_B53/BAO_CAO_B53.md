# QUESTION BANK V254 B53 | BÁO CÁO CẬP NHẬT CÓ KIỂM TOÁN

- Nguồn: V254 B52 ZIP. Không xóa 150 Word gốc.
- B53 thêm **170 câu biên soạn**, thuộc **17 nhóm phương pháp ứng viên** trên 17 chủ đề.
- Tổng nhãn câu (đếm trực tiếp đầu đoạn Word): **95224 → 95394**.
- Số nhãn ít nhất / Word: **632**; số Word: **150/150**.
- B53 qua phép kiểm toán học theo từng câu **170/170**, kiểm tra trùng nguyên văn với các JSONL B46–B52 và trong B53; CRC của ZIP đạt.
- **Không được công bố 5.000–7.500 dạng toán độc lập được chứng nhận.** Nhãn phương pháp máy gán không thay thế đánh giá ngữ nghĩa; nhiều bài cũ chỉ đổi tham số.
- Số nhãn câu không chứng minh câu hỏi nào đã qua kiểm định sư phạm độc lập.

## Phương pháp B53

- 023 | Bảng chân trị của phép kéo theo | Nền tảng | 10 câu | Dùng p⇒q tương đương (¬p)∨q; chỉ sai khi p đúng, q sai.
- 040 | Nguyên lý Dirichlet tổng quát | Trung cấp | 10 câu | Muốn chắc chắn một nhóm có ít nhất r phần tử trong m nhóm, cần m(r−1)+1 phần tử.
- 043 | Giải đồng dư tuyến tính bằng nghịch đảo modulo | Nâng cao | 10 câu | Với gcd(a,m)=1, ax≡b (mod m) có nghiệm duy nhất modulo m, x≡a⁻¹b.
- 044 | Thuật toán Euclid tìm ước chung lớn nhất | Trung cấp | 10 câu | Chia liên tiếp lấy dư cho tới khi dư bằng 0; số chia cuối cùng khác 0 là UCLN.
- 058 | Xét đơn điệu dãy phân thức bằng hiệu hai số hạng | Trung cấp | 10 câu | Xét dấu u(n+1)−u(n), với u(n)=(an+b)/(n+c).
- 064 | Giới hạn căn thức bằng liên hợp | Trung cấp | 10 câu | Nhân liên hợp để khử chênh lệch hai căn rồi chia cho n.
- 069 | Hàm liên tục từng đoạn: khớp giới hạn hai phía | Trung cấp | 10 câu | Điều kiện liên tục tại a: lim trái = lim phải = f(a).
- 071 | Hợp thành phép tịnh tiến và phép quay | Nâng cao | 10 câu | Biến đổi tọa độ theo thứ tự; phép quay R90(x,y)=(-y,x).
- 077 | Đồng nhất thức Vandermonde trong nhị thức Newton | Nâng cao | 10 câu | Đếm một tập n phần tử từ hai nhóm r,s theo số k được chọn ở nhóm đầu.
- 080 | Phép quay O góc bội của 90 độ | Nền tảng | 10 câu | Dùng các quy tắc R90(x,y)=(-y,x), R180=(-x,-y), R270=(y,-x).
- 089 | Chứng minh đẳng thức tổng bằng quy nạp | Trung cấp | 10 câu | Chứng minh P(1) và S(n+1)=S(n)+f(n+1).
- 112 | Mặt cầu cắt mặt phẳng thành đường tròn | Trung cấp | 10 câu | Nếu d<R, bán kính giao tuyến r=sqrt(R²−d²).
- 121 | Đường trung trực từ quỹ tích |z−a|=|z−b| | Trung cấp | 10 câu | Bình phương hai môđun và khử x²+y² để được phương trình đường thẳng.
- 126 | Mặt phẳng tiếp xúc mặt cầu tại điểm đã biết | Trung cấp | 10 câu | Mặt phẳng tiếp xúc có vectơ pháp tuyến P−C và đi qua P.
- 128 | Tích phân xác định bằng phép đặt u=ax+b | Trung cấp | 10 câu | Đặt u=ax+b, du=a dx rồi đổi cận trước khi tính nguyên hàm.
- 139 | Tiệm cận xiên của phân thức hữu tỉ | Trung cấp | 10 câu | Chia đa thức: f(x)=mx+n+r/(dx+e) nên TC xiên y=mx+n.
- 146 | Vị trí tương đối hai đường thẳng Oxyz bằng tích hỗn tạp | Nâng cao | 10 câu | Xét u×v và (B−A)·(u×v) để phân biệt trùng, song song, cắt, chéo nhau.

## Nguồn đối chiếu phương pháp (không sao chép nguyên câu hỏi)

- https://www.vietjack.com/toan-lop-11/day-so-cap-so-cong-va-cap-so-nhan.jsp
- https://vietjack.com/toan-lop-11/trac-nghiem-cap-so-cong.jsp

## Hạn chế cần nêu trước khi nộp

1. 150 Word đạt số nhãn câu tối thiểu 500 từ B49, nhưng chưa có 50 dạng độc lập thực sự/chủ đề.
2. Các bài B53 thuộc dạng ứng viên; 10 câu mỗi dạng vẫn cần được duyệt đa dạng đề thật bởi giáo viên.
3. Phép kiểm tính toán độc lập bằng SymPy và logic đếm không đồng nghĩa kiểm định sư phạm.
