# QUESTION BANK V254 B54 | KIỂM TOÁN SỐ LƯỢNG VÀ ỨNG VIÊN DẠNG

## Kết quả kiểm chứng được
- Nguồn: ZIP B53 đang có trong `/mnt/data/Question_Bank_V254.zip` trước khi xây B54.
- Số Word gốc được bảo toàn: **150/150**.
- Tổng nhãn câu: **95,394 → 95,514**, tăng **120** câu có đề + đáp án + lời giải.
- Số nhóm phương pháp B54: **12** trên **12** chủ đề.
- Mỗi nhóm gồm đúng 10 bài, có phương pháp nêu rõ.
- Các công thức được đối chiếu bằng SymPy, số học hoặc kiểm tra ràng buộc (chi tiết ở `DANG_UNG_VIEN_B54.csv`).
- Trùng nguyên văn trong đợt B54 hoặc với JSONL B46–B53: **0** (so văn bản chuẩn hóa).
- Số chủ đề đạt ít nhất 500 nhãn câu: **150/150**.
- Tổng dạng độc lập được chứng nhận **riêng trong B54: 0**, bởi chưa hoàn thành kiểm tra trùng ngữ nghĩa trên toàn bộ nội dung và thẩm định bởi giáo viên. **12 chỉ là ứng viên**.
- Mục tiêu 50 dạng độc lập/chủ đề × 150 = 7.500 dạng, 75.000 câu: **CHƯA ĐƯỢC CHỨNG NHẬN**. Đã vượt ngưỡng đếm nhãn câu nhưng không thay thế kiểm định độc lập.

## Cần tiếp tục trước khi tuyên bố 100%
1. Phân tích toàn bộ 150 Word và nhóm theo đặc tả phương pháp (khác bản chất, khác yêu cầu tư duy), không dựa vào ID hoặc thay số.
2. Trong từng nhóm, thẩm định 10 câu thực sự đa dạng bối cảnh và đặt vấn đề, đúng điều kiện, giải thích hợp lý.
3. Rà soát độc lập đáp án/lời giải bởi giáo viên; đối chiếu đa dạng với phương pháp trong ngân hàng cũ.
4. Chỉ nhập các nhóm vượt đủ tiêu chí vào bộ đề chính của MATH_WEB; hiện ZIP là kho Word, chưa phải cập nhật SQLite website.

## Nguồn tham khảo phân dạng, không sao chép bài tập
- https://vietjack.com/toan-lop-10/
- https://www.vietjack.com/toan-lop-11/
