# QUESTION BANK V254 B52 | BÁO CÁO ĐỢT BỔ SUNG CÓ KIỂM TRA TOÁN HỌC

- Gốc: B51; 150 Word và 95.124 nhãn câu (theo kiểm toán B51).
- B52: +100 câu biên soạn riêng, chia 10 nhãn phương pháp ứng viên ở 9 chủ đề.
- Đã đối chiếu công thức/kết quả bằng phép tính trong mã lập bộ; kiểm tra không trùng nguyên văn với JSONL B46–B51.
- Tổng nhãn câu theo phép đếm quy ước B52: **95,224**.
- Số Word: 150, kiểm tra CRC toàn bộ ZIP sau đóng gói.
- Khoảng cách với mục tiêu: đã vượt ngưỡng 75.000 nhãn câu, nhưng **chưa chứng minh 7.500 dạng toán độc lập** (50 dạng/chủ đề). Không khẳng định hoàn thành chất lượng 100%.
- Các câu từ B46–B51 nhiều biến thể tham số. Kiểm tra trùng nguyên văn không thay thế kiểm tra trùng ngữ nghĩa hoặc đánh giá giáo viên.

## 10 nhãn phương pháp ứng viên B52

- Chủ đề 020: **020-NL** | Hệ đối xứng qua tổng và tích | 10 câu | Trung cấp
- Chủ đề 025: **025-PAR** | Tổng hệ số bậc chẵn/lẻ qua P(1), P(−1) | 10 câu | Trung cấp
- Chủ đề 025: **025-DER** | Tổng hệ số có trọng số qua đạo hàm | 10 câu | Nâng cao
- Chủ đề 032: **032-VAR** | Phương sai từ dữ liệu thô bằng công thức hai mômen | 10 câu | Trung cấp
- Chủ đề 056: **056-THR** | Số bước tối thiểu để tổng cấp số cộng đạt ngưỡng | 10 câu | Nâng cao
- Chủ đề 057: **057-INF** | Tổng cấp số nhân vô hạn hội tụ | 10 câu | Trung cấp
- Chủ đề 119: **119-QUAD** | Phương trình bậc hai theo a^x | 10 câu | Nâng cao
- Chủ đề 132: **132-DIST** | Khoảng cách điểm–mặt phẳng trong Oxyz | 10 câu | Nền tảng
- Chủ đề 147: **147-HYP** | Xác suất lấy mẫu không hoàn lại | 10 câu | Trung cấp
- Chủ đề 150: **150-OPT** | Tối ưu hàm bậc hai bằng đạo hàm | 10 câu | Trung cấp

## Nguồn đối chiếu (không sao chép nguyên đề)

- https://www.vietjack.com/toan-lop-11/index.jsp
- https://www.vietjack.com/toan-lop-11/day-so-cap-so-cong-va-cap-so-nhan.jsp

## Cơ chế kiểm định

1. Giữ nguyên Word cũ và số câu cũ; bổ sung tài liệu thành phần mới vào đúng Word.
2. Mỗi nhóm B52 có mã phương pháp, mức độ, đề bài, đáp án và lời giải từng bước.
3. Phép kiểm toán bằng công thức và so sánh nguyên văn với JSONL B46–B51; chưa xác nhận độc lập ngữ nghĩa.
4. Không công nhận các bản ghi chưa qua đánh giá sư phạm hoặc trùng ngữ nghĩa là “dạng toán độc lập đạt chuẩn”.
