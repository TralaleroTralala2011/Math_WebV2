# KIỂM TRA TOÁN HỌC B52

- Đã kiểm tra lại bằng chương trình thứ hai, độc lập với chương trình soạn: **100/100** phép kiểm số học/đại số đạt.
- Nhóm kiểm tra: nghiệm hệ đối xứng; tổng hệ số nhị thức theo chẵn/lẻ; tổng có trọng số bằng đạo hàm; phương sai; ngưỡng tổng cấp số cộng; tổng cấp số nhân hội tụ; phương trình mũ bậc hai; khoảng cách điểm-mặt phẳng; xác suất siêu bội; cực đại bằng đạo hàm.
- Hạn chế: không kiểm định đầy đủ chất lượng câu chữ, tính trùng phương pháp với 150 chủ đề cũ hoặc giá trị sư phạm. Đây **không** phải chứng nhận 7.500 dạng độc lập.
